"""Admin panel package."""
